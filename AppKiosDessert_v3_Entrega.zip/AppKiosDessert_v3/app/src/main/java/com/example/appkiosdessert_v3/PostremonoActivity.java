package com.example.appkiosdessert_v3;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import kotlin.contracts.Returns;

public class PostremonoActivity extends AppCompatActivity {

    Button atras;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_postremono);


    atras = (Button) findViewById(R.id.button);

    atras.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                startActivity(new Intent(PostremonoActivity.this, ProductActivity.class));

            }
      });

    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_inicio:
                Toast.makeText(this, "Home", Toast.LENGTH_SHORT).show();
                Intent intent_home = new Intent(this, MainActivity.class);
                startActivity(intent_home);
                break;
            case R.id.action_productos:
                Toast.makeText(this, "Productos", Toast.LENGTH_SHORT).show();
                Intent intent_productos = new Intent(this, ProductActivity.class);
                startActivity(intent_productos);
                break;
            case R.id.action_servicios:
                Toast.makeText(this, "Servicios", Toast.LENGTH_SHORT).show();
                Intent intent_servicios = new Intent(this, ServiciosActivity.class);
                startActivity(intent_servicios);
                break;
            case R.id.action_sucursales:
                Toast.makeText(this, "Sucursales", Toast.LENGTH_SHORT).show();
                Intent intent_sucursales = new Intent(this, SucursalesActivity.class);
                startActivity(intent_sucursales);

                break;

        }
        return super.onOptionsItemSelected(item);
    }

}