package com.example.appkiosdessert_v3;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

public class ProductActivity extends AppCompatActivity implements View.OnClickListener {

    Button boton;
    Button b2;
    Button b3;
    Button b4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product);

        boton = (Button) findViewById(R.id.descripcion);
        boton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                startActivity(new Intent(ProductActivity.this, PostremonoActivity.class));

            }
        });

        b2 = (Button) findViewById(R.id.descripcion2);
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                startActivity(new Intent(ProductActivity.this, PostreflorActivity.class));

            }
        });

        b3 = (Button) findViewById(R.id.button3);
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                startActivity(new Intent(ProductActivity.this, PostrerenitoActivity.class));

            }
        });

        b4 = (Button) findViewById(R.id.button4);
          b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                startActivity(new Intent(ProductActivity.this, PostrearbolitoActivity.class));

            }
        });


        ImageButton boton1 = (ImageButton) findViewById(R.id.imageButton2);

        boton1.setOnClickListener((new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Toast notificacion = Toast.makeText(ProductActivity.this, "Postre Moño 12 porciones $70000", Toast.LENGTH_SHORT);
            notificacion.show();
            }
        }));

        ImageButton boton2 = (ImageButton) findViewById(R.id.imageButton4);

        boton2.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast notificacion = Toast.makeText(ProductActivity.this, "Postre Flor 9 porciones $60000", Toast.LENGTH_SHORT);
                notificacion.show();
            }
        }));

        ImageButton boton3 = (ImageButton) findViewById(R.id.imageButton5);

        boton3.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast notificacion = Toast.makeText(ProductActivity.this, "Postre Renito 4 porciones $25000", Toast.LENGTH_SHORT);
                notificacion.show();
            }
        }));

        ImageButton boton4 = (ImageButton) findViewById(R.id.imageButton6);

        boton4.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast notificacion = Toast.makeText(ProductActivity.this, "Postre Arbolito porción personal $8500", Toast.LENGTH_SHORT);
                notificacion.show();
            }
        }));

    }

    @Override
    public void onClick(View view) {

    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_inicio:
                Toast.makeText(this, "Home", Toast.LENGTH_SHORT).show();
                Intent intent_home = new Intent(this, MainActivity.class);
                startActivity(intent_home);
                break;
            case R.id.action_productos:
                Toast.makeText(this, "Productos", Toast.LENGTH_SHORT).show();
                Intent intent_productos = new Intent(this, ProductActivity.class);
                startActivity(intent_productos);
                break;
            case R.id.action_servicios:
                Toast.makeText(this, "Servicios", Toast.LENGTH_SHORT).show();
                Intent intent_servicios = new Intent(this, ServiciosActivity.class);
                startActivity(intent_servicios);
                break;
            case R.id.action_sucursales:
                Toast.makeText(this, "Sucursales", Toast.LENGTH_SHORT).show();
                Intent intent_sucursales = new Intent(this, SucursalesActivity.class);
                startActivity(intent_sucursales);

                break;

        }
        return super.onOptionsItemSelected(item);
    }
}