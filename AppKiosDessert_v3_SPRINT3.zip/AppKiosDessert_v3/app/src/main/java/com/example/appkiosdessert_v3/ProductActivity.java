package com.example.appkiosdessert_v3;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

import java.util.ArrayList;

public class ProductActivity extends AppCompatActivity {
    ArrayList<Postre> arrayList_postre;
    RecyclerView recyclerView_postre;
    AdaptadorPostre adaptadorPostre;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product);


        arrayList_postre = new ArrayList<>();

        recyclerView_postre = findViewById(R.id.id_pa_recyclerview_postre);
        recyclerView_postre.addItemDecoration(new DividerItemDecoration(this,DividerItemDecoration.VERTICAL));
        recyclerView_postre.setLayoutManager(new LinearLayoutManager(this,LinearLayoutManager.VERTICAL,false));

        llenarPostre();
        adaptadorPostre = new AdaptadorPostre(arrayList_postre);
        recyclerView_postre.setAdapter(adaptadorPostre);

    }

    private void llenarPostre() {

        arrayList_postre.add(new Postre("Postre Moño","12 Porciones \nMaracuya",R.drawable.mono_96));
        arrayList_postre.add(new Postre("Postre Flor","9 Porciones \nMaracuya",R.drawable.flor_96));
        arrayList_postre.add(new Postre("Postre Renito","4 Porciones \nMaracuya",R.drawable.renito_96));
        arrayList_postre.add(new Postre("Postre Arbolito","Porcion Individual \nMaracuya",R.drawable.arbolito_96));
        arrayList_postre.add(new Postre("Postre Fresa","Porcion Individual \nFresa",R.drawable.p5_96));
        arrayList_postre.add(new Postre("Postre Nata","Porcion Individual \nLecherita",R.drawable.p6_96));
        arrayList_postre.add(new Postre("Postre Taza","Porcion Individual \nChocolate",R.drawable.p7_96));
        arrayList_postre.add(new Postre("Postre Gelatina","Porcion Individual \nFranbuesa",R.drawable.p8_96));
        arrayList_postre.add(new Postre("Postre Pudin","Porcion Individual \nArequipe",R.drawable.p9_96));
        arrayList_postre.add(new Postre("Postre Triangulo","Porcion Individual \nTamarindo",R.drawable.p10_96));
        arrayList_postre.add(new Postre("Postre Cuadrado","Dos Porciones \nVainilla",R.drawable.p11_96));
        arrayList_postre.add(new Postre("Postre Recubierto","6 porciones \nCaramelo",R.drawable.p12_96));

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_inicio:
                Toast.makeText(this, "Home", Toast.LENGTH_SHORT).show();
                Intent intent_home = new Intent(this, MainActivity.class);
                startActivity(intent_home);
                break;
            case R.id.action_productos:
                Toast.makeText(this, "Productos", Toast.LENGTH_SHORT).show();
                Intent intent_productos = new Intent(this, ProductActivity.class);
                startActivity(intent_productos);
                break;
            case R.id.action_servicios:
                Toast.makeText(this, "Servicios", Toast.LENGTH_SHORT).show();
                Intent intent_servicios = new Intent(this, ServiciosActivity.class);
                startActivity(intent_servicios);
                break;
            case R.id.action_sucursales:
                Toast.makeText(this, "Sucursales", Toast.LENGTH_SHORT).show();
                Intent intent_sucursales = new Intent(this, SucursalesActivity.class);
                startActivity(intent_sucursales);

                break;

        }
        return super.onOptionsItemSelected(item);
    }
}