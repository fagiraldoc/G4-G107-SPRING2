package com.example.appkiosdessert_v3;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import java.util.ArrayList;

public class ServiciosActivity extends AppCompatActivity {
    ArrayList<Servicios> arrayList_servicios;
    RecyclerView recyclerView_servicios;
    AdaptadorServicios adaptadorServicios;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_servicios);

        arrayList_servicios = new ArrayList<>();
        recyclerView_servicios = findViewById(R.id.id_as_recyclerview_servicios);
        recyclerView_servicios.addItemDecoration(new DividerItemDecoration(this,DividerItemDecoration.VERTICAL));
        recyclerView_servicios.setLayoutManager(new LinearLayoutManager(this,LinearLayoutManager.VERTICAL,false));

        llenarServicios();
        adaptadorServicios = new AdaptadorServicios(arrayList_servicios);
        recyclerView_servicios.setAdapter(adaptadorServicios);


    }

    private void llenarServicios() {

        arrayList_servicios.add(new Servicios("Pago Nequi",R.drawable.s1_96));
        arrayList_servicios.add(new Servicios("Domicilios",R.drawable.s2_96));
        arrayList_servicios.add(new Servicios("Entregas Personalizadas",R.drawable.s3_96));
        arrayList_servicios.add(new Servicios("Asesoria telefonica",R.drawable.s4_96));
        arrayList_servicios.add(new Servicios("Envoltura Regalo",R.drawable.s5_96));
        arrayList_servicios.add(new Servicios("PQR",R.drawable.s6_96));
        arrayList_servicios.add(new Servicios("Comunicacion Asesor",R.drawable.s7_96));
        arrayList_servicios.add(new Servicios("Redes Sociales",R.drawable.s8_96));
        arrayList_servicios.add(new Servicios("Pago Contraentrega",R.drawable.s9_96));
        arrayList_servicios.add(new Servicios("Acompañamiento",R.drawable.s10_96));
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_inicio:
                Toast.makeText(this, "Home", Toast.LENGTH_SHORT).show();
                Intent intent_home = new Intent(this, MainActivity.class);
                startActivity(intent_home);
                break;
            case R.id.action_productos:
                Toast.makeText(this, "Productos", Toast.LENGTH_SHORT).show();
                Intent intent_productos = new Intent(this, ProductActivity.class);
                startActivity(intent_productos);
                break;
            case R.id.action_servicios:
                Toast.makeText(this, "Servicios", Toast.LENGTH_SHORT).show();
                Intent intent_servicios = new Intent(this, ServiciosActivity.class);
                startActivity(intent_servicios);
                break;
            case R.id.action_sucursales:
                Toast.makeText(this, "Sucursales", Toast.LENGTH_SHORT).show();
                Intent intent_sucursales = new Intent(this, SucursalesActivity.class);
                startActivity(intent_sucursales);

                break;

        }
        return super.onOptionsItemSelected(item);
    }
}