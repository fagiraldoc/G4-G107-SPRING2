package com.example.appkiosdessert_v3;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class AdaptadorPostre extends RecyclerView.Adapter<AdaptadorPostre.ViewHolderPostre> {

    ArrayList<Postre> ListaPostre;

    public AdaptadorPostre(ArrayList<Postre> listaPostre) {
        ListaPostre = listaPostre;
    }

    @NonNull
    @Override
    public AdaptadorPostre.ViewHolderPostre onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.lista_items,null, false);
        return new ViewHolderPostre(view);
    }

    @Override
    public void onBindViewHolder(@NonNull AdaptadorPostre.ViewHolderPostre holder, int position) {
        holder.getTextView_nombre().setText(ListaPostre.get(position).getNombre());
        holder.getTextView_informacion().setText(ListaPostre.get(position).getInfo());
        holder.getImageView_foto().setImageResource(ListaPostre.get(position).getFoto());

    }

    @Override
    public int getItemCount() {
        return ListaPostre.size();
    }

    public class ViewHolderPostre extends RecyclerView.ViewHolder {
        private TextView textView_nombre, textView_informacion;
        private ImageView imageView_foto;

        public ViewHolderPostre(@NonNull View itemView) {
            super(itemView);
            textView_nombre = itemView.findViewById(R.id.id_il_textview_nombre);
            textView_informacion =itemView.findViewById(R.id.id_il_textview_info);
            imageView_foto = itemView.findViewById(R.id.id_il_imagenview_foto);
        }

        public TextView getTextView_nombre() {
            return textView_nombre;
        }

        public void setTextView_nombre(TextView textView_nombre) {
            this.textView_nombre = textView_nombre;
        }

        public TextView getTextView_informacion() {
            return textView_informacion;
        }

        public void setTextView_informacion(TextView textView_informacion) {
            this.textView_informacion = textView_informacion;
        }

        public ImageView getImageView_foto() {
            return imageView_foto;
        }

        public void setImageView_foto(ImageView imageView_foto) {
            this.imageView_foto = imageView_foto;
        }
    }
}
