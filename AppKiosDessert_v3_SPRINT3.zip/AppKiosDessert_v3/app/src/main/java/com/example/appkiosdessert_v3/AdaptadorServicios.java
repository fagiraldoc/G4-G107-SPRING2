package com.example.appkiosdessert_v3;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class AdaptadorServicios extends RecyclerView.Adapter<AdaptadorServicios.ViewHolderServicios> {

    ArrayList<Servicios> ListaServicios;

    public AdaptadorServicios(ArrayList<Servicios> listaServicios) {
        ListaServicios = listaServicios;
    }

    @NonNull
    @Override
    public AdaptadorServicios.ViewHolderServicios onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.lista_items2,null, false);
        return new ViewHolderServicios(view);
    }

    @Override
    public void onBindViewHolder(@NonNull AdaptadorServicios.ViewHolderServicios holder, int position) {
        holder.getTextView_nombre().setText(ListaServicios.get(position).getNombre());
        holder.getImageView_foto().setImageResource(ListaServicios.get(position).getFoto());

    }

    @Override
    public int getItemCount() {
        return ListaServicios.size();
    }

    public class ViewHolderServicios extends RecyclerView.ViewHolder {
        private TextView textView_nombre;
        private ImageView imageView_foto;

        public ViewHolderServicios(@NonNull View itemView) {
            super(itemView);
            textView_nombre = itemView.findViewById(R.id.id_il_textview_nombre2);
            imageView_foto = itemView.findViewById(R.id.id_il_imagenview_foto2);
        }

        public TextView getTextView_nombre() {
            return textView_nombre;
        }

        public void setTextView_nombre(TextView textView_nombre) {
            this.textView_nombre = textView_nombre;
        }

        public ImageView getImageView_foto() {
            return imageView_foto;
        }

        public void setImageView_foto(ImageView imageView_foto) {
            this.imageView_foto = imageView_foto;
        }
    }


}
