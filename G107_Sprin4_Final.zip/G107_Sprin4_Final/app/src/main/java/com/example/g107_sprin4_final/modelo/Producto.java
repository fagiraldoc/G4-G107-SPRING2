package com.example.g107_sprin4_final.modelo;

public class Producto {
    private  String identificadorProducto;
    private  String nombreProducto;
    private  String porcionProdcuto;
    private  String saborProdcuto;
    private  String fotoProducto;

    public Producto() {

    }

    public Producto(String identificadorProducto, String nombreProducto, String porcionProdcuto, String saborProdcuto, String fotoProducto) {
        this.identificadorProducto = identificadorProducto;
        this.nombreProducto = nombreProducto;
        this.porcionProdcuto = porcionProdcuto;
        this.saborProdcuto = saborProdcuto;
        this.fotoProducto = fotoProducto;
    }

    public String getIdentificadorProducto() {
        return identificadorProducto;
    }

    public void setIdentificadorProducto(String identificadorProducto) {
        this.identificadorProducto = identificadorProducto;
    }

    public String getNombreProducto() {
        return nombreProducto;
    }

    public void setNombreProducto(String nombreProducto) {
        this.nombreProducto = nombreProducto;
    }

    public String getPorcionProdcuto() {
        return porcionProdcuto;
    }

    public void setPorcionProdcuto(String porcionProdcuto) {
        this.porcionProdcuto = porcionProdcuto;
    }

    public String getSaborProdcuto() {
        return saborProdcuto;
    }

    public void setSaborProdcuto(String saborProdcuto) {
        this.saborProdcuto = saborProdcuto;
    }

    public String getFotoProducto() {
        return fotoProducto;
    }

    public void setFotoProducto(String fotoProducto) {
        this.fotoProducto = fotoProducto;
    }
}