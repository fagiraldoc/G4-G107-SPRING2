package com.example.g107_sprin4_final.vista;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;

import com.example.g107_sprin4_final.R;
import com.example.g107_sprin4_final.presentador.PresentadorLogin;
import com.google.firebase.auth.FirebaseAuth;


public class VistaLogin extends AppCompatActivity implements View.OnClickListener {
    ImageButton imageButton_registrar, imageButton_ingresar;
    EditText editText_correo, editText_clave;

    FirebaseAuth firebaseAuth;
    PresentadorLogin presentadorLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.vista_login);

        imageButton_registrar =findViewById(R.id.id_vl_imagebutton_registrar);
        imageButton_ingresar =findViewById(R.id.id_vl_imagebutton_ingresar);

        editText_correo =findViewById(R.id.id_vl_editttext_correo);
        editText_clave =findViewById(R.id.id_vl_editttext_clave);

        imageButton_registrar.setOnClickListener(this);
        imageButton_ingresar.setOnClickListener(this);

        firebaseAuth = FirebaseAuth.getInstance();

        presentadorLogin = new PresentadorLogin(VistaLogin.this,firebaseAuth);

    }


    @Override
    public void onClick(View view) {
        Intent intent_registrar;
        String valor_correo, valor_clave;

        switch (view.getId()) {

            case R.id.id_vl_imagebutton_registrar:
                intent_registrar = new Intent(VistaLogin.this, VistaRegistro.class);
                startActivity(intent_registrar);
                break;

            case R.id.id_vl_imagebutton_ingresar:
                valor_correo =editText_correo.getText().toString().trim();
                valor_clave = editText_clave.getText().toString().trim();
                presentadorLogin.iniciarSesion(valor_correo,valor_clave);
                break;
        }

    }

}