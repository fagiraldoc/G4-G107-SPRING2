package com.example.g107_sprin4_final.vista;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.g107_sprin4_final.R;
import com.example.g107_sprin4_final.modelo.Producto;
import com.example.g107_sprin4_final.presentador.PresentadorProducto;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.io.IOException;
import java.util.ArrayList;

public class VistaPrincipal extends AppCompatActivity implements AdaptadorProducto.OnProductoListener {

    EditText editTextNombreProducto, editTextPorcionProducto, editTextSaborProducto, editTextEditarNombreProducto, editTextEditarPorcionProducto, editTextEditarSaborProducto;
    Button buttonAgregarProducto, buttonCargarFoto, buttonCancelar;
    ImageView imageViewFotoProducto;

    ArrayList<Producto> listaProductos;
    RecyclerView recyclerViewProductos;
    AdaptadorProducto adaptadorProducto;
    Producto productoSeleccionado;

    Uri filePath;


    private final int PICK_FOTO = 1;

    private PresentadorProducto presentadorProducto;
    private FirebaseDatabase firebaseDatabase;
    private DatabaseReference databaseReference;
    private StorageReference storageReference;

    private LinearLayout linearLayoutEditar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.vista_principal);
        inicializarFirabase();

        presentadorProducto = new PresentadorProducto(VistaPrincipal.this, databaseReference, storageReference);

        linearLayoutEditar = findViewById(R.id.id_vp_linearlayout);
        editTextEditarNombreProducto = findViewById(R.id.id_vp_edittext_nombre_producto);
        editTextEditarPorcionProducto = findViewById(R.id.id_vp_edittext_porcion_producto);
        editTextSaborProducto = findViewById(R.id.id_vp_edittext_sabor_producto);
        recyclerViewProductos = findViewById(R.id.id_vp_recyclerview_postres);
        buttonCancelar = findViewById(R.id.id_vp_button_cancelar);


        buttonCancelar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                linearLayoutEditar.setVisibility(View.GONE);
                productoSeleccionado = null;
            }
        });

        listaProductos = new ArrayList<>();
        recyclerViewProductos.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL));
        recyclerViewProductos.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));

        listarProductos();


    }

    private void listarProductos() {

        databaseReference.child("producto").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                listaProductos.clear();
                for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    Producto producto = dataSnapshot.getValue(Producto.class);
                    listaProductos.add(producto);
                }
                adaptadorProducto = new AdaptadorProducto(listaProductos, VistaPrincipal.this);
                recyclerViewProductos.setAdapter(adaptadorProducto);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    private void inicializarFirabase() {

        firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReference();
        storageReference = FirebaseStorage.getInstance().getReference();
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        switch (item.getItemId()) {

            case R.id.id_m_item_agragar_producto:
                crearProducto();
                break;
            case R.id.id_m_item_actualizar_producto:
                actualizarProducto();
                break;
            case R.id.id_m_item_eliminar_producto:
                eliminarProducto();
                break;
            case R.id.id_m_item_item_sucursales:
                Intent intent_mapa = new Intent(VistaPrincipal.this, VistaMapa.class);
                startActivity(intent_mapa);
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    private void crearProducto() {

        AlertDialog.Builder builder;
        AlertDialog alerDialog;
        View view;

        builder = new AlertDialog.Builder(VistaPrincipal.this);
        view = LayoutInflater.from(VistaPrincipal.this).inflate(R.layout.agregar_producto, null);
        builder.setView(view);
        alerDialog = builder.create();
        alerDialog.show();

        editTextNombreProducto = view.findViewById(R.id.id_ap_edittext_nombre_producto);
        editTextPorcionProducto = view.findViewById(R.id.id_ap_edittext_porcion_producto);
        editTextSaborProducto = view.findViewById(R.id.id_ap_edittext_sabor_producto);
        buttonCargarFoto = view.findViewById(R.id.id_ap_button_cargar_imagen);
        buttonAgregarProducto = view.findViewById(R.id.id_ap_button_insertar_producto);
        imageViewFotoProducto = view.findViewById(R.id.id_ap_imageview_foto_producto);

        buttonCargarFoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent_galeria;

                intent_galeria = new Intent();
                intent_galeria.setType("image/*");
                intent_galeria.setAction(Intent.ACTION_PICK);
                startActivityForResult(intent_galeria, PICK_FOTO);

            }
        });

        buttonAgregarProducto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String nombreProducto, porcionProducto, saborProducto;

                nombreProducto = editTextNombreProducto.getText().toString();
                porcionProducto = editTextPorcionProducto.getText().toString();
                saborProducto = editTextSaborProducto.getText().toString();

                if (nombreProducto.isEmpty() || nombreProducto.length() < 5) {
                    showError(editTextNombreProducto, "Producto invalido");
                } else if (porcionProducto.isEmpty() || porcionProducto.length() < 1) {
                    showError(editTextPorcionProducto, "Producto invalido");
                } else if (saborProducto.isEmpty() || saborProducto.length() < 3) {
                    showError(editTextSaborProducto, "Producto invalido");

                } else if (filePath == null) {
                    Toast.makeText(VistaPrincipal.this, "No se ha seleccionado imagen", Toast.LENGTH_SHORT).show();

                } else {
                    presentadorProducto.agregarProducto(nombreProducto, porcionProducto, saborProducto, filePath);
                    alerDialog.dismiss();
                    filePath = null;


                }

            }
        });


    }


    private void actualizarProducto() {
        if (productoSeleccionado != null) {
            productoSeleccionado.setNombreProducto(editTextEditarNombreProducto.getText().toString());
            productoSeleccionado.setPorcionProdcuto(editTextEditarPorcionProducto.getText().toString());
            productoSeleccionado.setSaborProdcuto(editTextSaborProducto.getText().toString());
            presentadorProducto.actualizarProducto(productoSeleccionado);
            linearLayoutEditar.setVisibility(View.GONE);
            productoSeleccionado = null;

        } else {
            Toast.makeText(VistaPrincipal.this, "Debe escoger un producto", Toast.LENGTH_SHORT).show();
        }
    }

    private void eliminarProducto() {
        if (productoSeleccionado != null) {
            presentadorProducto.eliminarProducto(productoSeleccionado);
            linearLayoutEditar.setVisibility(View.GONE);
            productoSeleccionado = null;
        } else {
            Toast.makeText(VistaPrincipal.this, "Debe escoger un producto", Toast.LENGTH_SHORT).show();
        }

    }

    private void showError(EditText campo, String mensaje) {
        campo.requestFocus();
        campo.setError(mensaje);
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_FOTO && resultCode == RESULT_OK && data != null && data.getData() != null) {

            filePath = data.getData();
            try {
                Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), filePath);
                imageViewFotoProducto.setImageBitmap(bitmap);

            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void onProductoClick(int position) {
        productoSeleccionado = new Producto();

        productoSeleccionado.setIdentificadorProducto(listaProductos.get(position).getIdentificadorProducto());
        productoSeleccionado.setFotoProducto(listaProductos.get(position).getFotoProducto());
        linearLayoutEditar.setVisibility(View.VISIBLE);

        editTextEditarNombreProducto.setText(listaProductos.get(position).getNombreProducto());
        editTextEditarPorcionProducto.setText(listaProductos.get(position).getPorcionProdcuto());
        editTextSaborProducto.setText(listaProductos.get(position).getSaborProdcuto());


    }
}