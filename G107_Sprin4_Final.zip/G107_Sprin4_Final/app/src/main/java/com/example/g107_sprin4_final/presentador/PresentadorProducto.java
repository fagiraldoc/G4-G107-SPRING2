package com.example.g107_sprin4_final.presentador;

import android.app.ProgressDialog;
import android.content.Context;
import android.net.Uri;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.example.g107_sprin4_final.modelo.Producto;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.util.Date;
import java.util.UUID;

public class PresentadorProducto {
    private Context context;
    private DatabaseReference databaseReference;
    private StorageReference storageReference;


    public PresentadorProducto(Context context, DatabaseReference databaseReference, StorageReference storageReference) {
        this.context = context;
        this.databaseReference = databaseReference;
        this.storageReference = storageReference;
    }

    public Context getContext() {
        return context;
    }

    public void setContext(Context context) {
        this.context = context;
    }

    public DatabaseReference getDatabaseReference() {
        return databaseReference;
    }

    public void setDatabaseReference(DatabaseReference databaseReference) {
        this.databaseReference = databaseReference;
    }

    public StorageReference getStorageReference() {
        return storageReference;
    }

    public void setStorageReference(StorageReference storageReference) {
        this.storageReference = storageReference;
    }

    public void agregarProducto(String nombreProducto, String porcionProducto, String saborProducto, Uri filePath) {

        String identificacionproducto;

        identificacionproducto = UUID.randomUUID().toString();
        StorageReference fotoProducto;

        ProgressDialog progressDialog = new ProgressDialog(context);
        progressDialog.setMessage("Agregando producto");
        progressDialog.setCancelable(false);
        progressDialog.show();

        fotoProducto = storageReference.child("fotos_producto").child(new Date().toString());

        fotoProducto.putFile(filePath).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                Task <Uri> uriTask =taskSnapshot.getStorage().getDownloadUrl();
                while (!uriTask.isSuccessful());

                Uri LinkDescargaFoto = uriTask.getResult();

                Producto producto = new Producto(identificacionproducto,nombreProducto,porcionProducto,saborProducto,LinkDescargaFoto.toString());

                getDatabaseReference().child("producto").child(producto.getIdentificadorProducto()).setValue((producto)).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        progressDialog.dismiss();
                        Toast.makeText(context,"producto Registrado con exito", Toast.LENGTH_SHORT).show();
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        progressDialog.dismiss();
                        Toast.makeText(context,"Error" + e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });

            }
        });
    }
    public void actualizarProducto(Producto productoSeleccionado) {
        ProgressDialog progressDialog = new ProgressDialog(context);
        progressDialog.setMessage("Agregando Producto...");
        progressDialog.setCancelable(false);
        progressDialog.show();

        databaseReference.child("producto").child(productoSeleccionado.getIdentificadorProducto()).setValue(productoSeleccionado).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                progressDialog.dismiss();
                Toast.makeText(context, "producto Actualizado", Toast.LENGTH_SHORT).show();
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                progressDialog.dismiss();
                Toast.makeText(context, e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

    }


    public void eliminarProducto(Producto productoSeleccionado) {
        ProgressDialog progressDialog = new ProgressDialog(context);
        progressDialog.setMessage("Agregando Producto...");
        progressDialog.setCancelable(false);
        progressDialog.show();

        databaseReference.child("producto").child(productoSeleccionado.getIdentificadorProducto()).removeValue().addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                progressDialog.dismiss();
                Toast.makeText(context,"Producto eliminado", Toast.LENGTH_SHORT).show();
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                progressDialog.dismiss();
                Toast.makeText(context, e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

    }



/*    public void actualizarProducto(Producto productoSeleccionado) {
        ProgressDialog progressDialog = new ProgressDialog(context);
        progressDialog.setMessage("Agregando Producto...");
        progressDialog.setCancelable(false);
        progressDialog.show();

        databaseReference.child("producto").child(productoSeleccionado.getIdentificadorProducto()).setValue(productoSeleccionado).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                progressDialog.dismiss();
                Toast.makeText(context, "producto Actualizado", Toast.LENGTH_SHORT).show();
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                progressDialog.dismiss();
                Toast.makeText(context, e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

    }*/
}
